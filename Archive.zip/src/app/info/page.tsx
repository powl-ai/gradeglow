import LegalCenterPage from "../../components/LegalCenterPage";

export default function InfoPage() {
  return <LegalCenterPage />;
}
